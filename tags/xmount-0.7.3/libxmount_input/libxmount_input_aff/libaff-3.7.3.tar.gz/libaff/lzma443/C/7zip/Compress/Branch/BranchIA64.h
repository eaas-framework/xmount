// BranchIA64.h

#ifndef __BRANCH_IA64_H
#define __BRANCH_IA64_H

#include "BranchTypes.h"

UInt32 IA64_Convert(Byte *data, UInt32 size, UInt32 nowPos, int encoding);

#endif
