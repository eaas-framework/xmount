// BinTree2.h

#ifndef __BINTREE2_H
#define __BINTREE2_H

#define BT_NAMESPACE NBT2

#include "BinTreeMain.h"

#undef BT_NAMESPACE

#endif
