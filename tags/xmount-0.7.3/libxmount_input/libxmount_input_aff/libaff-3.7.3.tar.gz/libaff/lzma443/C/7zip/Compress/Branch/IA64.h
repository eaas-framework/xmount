// IA64.h

#ifndef __IA64_H
#define __IA64_H

#include "BranchCoder.h"

MyClassA(BC_IA64, 0x04, 1)

#endif
