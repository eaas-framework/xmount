/*
 * This file is a work of a US government employee and as such is in the Public domain.
 * Simson L. Garfinkel, March 12, 2012
 */

extern struct af_vnode vnode_vmdk;
extern struct af_vnode vnode_dmg;
extern struct af_vnode vnode_sparseimage;

