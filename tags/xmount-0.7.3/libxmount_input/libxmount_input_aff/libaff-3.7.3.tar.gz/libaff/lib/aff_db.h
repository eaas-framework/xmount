/* Distributed under the 4-part Berkeley License */

#ifdef __cplusplus
extern "C" {
#endif
    int	aff_find_seg(AFFILE *af,const char *segname, uint32_t *arg,size_t *datasize, size_t *segsize);
#ifdef __cplusplus
}
#endif

